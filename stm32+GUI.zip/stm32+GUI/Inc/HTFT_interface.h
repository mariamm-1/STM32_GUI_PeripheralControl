/*
 * HTFT_interface.h
 *
 *  Created on: Sep 3, 2025
 *      Author: maria
 */

#ifndef HTFT_INTERFACE_H_
#define HTFT_INTERFACE_H_

void HTFT_voidinit();

void HTFT_voiddisplay(const u16*copy_pu16PTR);

#endif /* HTFT_INTERFACE_H_ */
