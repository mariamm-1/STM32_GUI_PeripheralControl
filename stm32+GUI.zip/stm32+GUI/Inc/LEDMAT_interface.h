/*
 * LEDMAT_interface.h
 *
 *  Created on: Aug 31, 2025
 *      Author: maria
 */

#ifndef LEDMAT_INTERFACE_H_
#define LEDMAT_INTERFACE_H_

void HLEDMAT_voidinit();

void HLEDMAT_voiddisplay(u8*copy_pu8ptr);
void ledmat_name();




#endif /* LEDMAT_INTERFACE_H_ */
