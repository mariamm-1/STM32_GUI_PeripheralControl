/*
 * MSPI_config.h
 *
 *  Created on: Sep 3, 2025
 *      Author: maria
 */

#ifndef MSPI_CONFIG_H_
#define MSPI_CONFIG_H_



#endif /* MSPI_CONFIG_H_ */
