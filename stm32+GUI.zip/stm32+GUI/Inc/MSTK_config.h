/*
 * MSTK_config.h
 *
 *  Created on: Aug 31, 2025
 *      Author: maria
 */

#ifndef MSTK_CONFIG_H_
#define MSTK_CONFIG_H_


/*
 * choose between
 * 1- STK_AHB
 * 2- STK_AHB_8
 */

#define SYSTICK_CLOCK_SOURCE STK_AHB_8



#endif /* MSTK_CONFIG_H_ */
